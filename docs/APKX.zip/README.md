# APKX

> Android Package Auditor — static analysis of AndroidManifest.xml, signing certificates, and hardcoded secrets inside APK files.

![Python](https://img.shields.io/badge/Python-3.8%2B-3776AB?style=flat-square&logo=python&logoColor=white)
![Platform](https://img.shields.io/badge/Platform-Linux%20%7C%20macOS%20%7C%20Windows-557C94?style=flat-square)
![License](https://img.shields.io/badge/License-MIT-blue?style=flat-square)
![Status](https://img.shields.io/badge/Status-Active-brightgreen?style=flat-square)

---

## Overview

APKX is a **static-only** Android security auditor: feed it an `.apk` file and it audits the manifest for risky configuration (exported components, debuggable builds, backup/cleartext flags), inspects the signing certificate (debug-keystore detection, expiry, signature scheme), and scans the package contents for hardcoded secrets and tokens. Built around the checks described in the OWASP MASVS/MASTG (Mobile Application Security Testing Guide). No emulator, no device, no dynamic instrumentation — everything runs against the file on disk.

---

## Modules

| Module | Description |
|---|---|
| `apk/manifest` | Parses `AndroidManifest.xml` (via androguard) — flags exported activities/services/receivers/providers with no protecting permission, `debuggable`, `allowBackup`, cleartext traffic, and dangerous permissions requested |
| `apk/cert` | Analyzes the signing certificate — detects the default Android **debug keystore** signature, expired certs, and legacy v1-only (JAR) signing |
| `apk/secrets` | Scans manifest/resources/dex strings for hardcoded AWS keys, Google API keys, Firebase URLs, Slack tokens, private key blocks, JWTs, and hardcoded password/API key assignments |

---

## Features

- **Static analysis only** — reads the APK file you provide, makes no network requests, installs nothing on a device
- **Console-based workflow** — same `use` / `set` / `show options` / `run` UX as the rest of the toolkit
- **MASVS/MASTG-aligned checks** — exported component analysis follows the same logic Android uses internally (explicit `exported` attribute, or implicit default based on intent-filter presence)
- **Debug-keystore fingerprinting** — flags apps accidentally signed with the default AOSP debug certificate, a common real-world finding
- **JSON report export** for portfolio/client evidence

---

## Requirements

```bash
pip install androguard
```

That's the only dependency — [androguard](https://github.com/androguard/androguard) handles APK parsing, binary AXML decoding, and certificate extraction.

---

## Installation

```bash
git clone https://github.com/<you>/APKX.git
cd APKX
pip install -r requirements.txt
python3 apkx.py
```

---

## Usage

```
apkx > show modules
apkx > use <module>
apkx > set APK /path/to/app.apk
apkx > run
```

### Core commands

```
use <module>            Load a module
set <OPTION> <value>    Set an option
show options            Show current module options
show modules            List available modules
run                     Execute the loaded module
show findings           Show findings collected this session
save report <file>      Export session findings to JSON
back                    Unload the current module
exit / quit             Exit the console
```

---

## Examples

**Full manifest audit:**
```
apkx > use apk/manifest
apkx (apk/manifest) > set APK ./samples/target.apk
apkx (apk/manifest) > run
```

**Check who signed it:**
```
apkx > use apk/cert
apkx (apk/cert) > set APK ./samples/target.apk
apkx (apk/cert) > run
```

**Hunt for hardcoded secrets:**
```
apkx > use apk/secrets
apkx (apk/secrets) > set APK ./samples/target.apk
apkx (apk/secrets) > run
```

---

## Output

```
apkx (apk/manifest) > run

[*] Package      : com.example.target
[*] Min/Target SDK: 21 / 33

[CRITICAL] android:debuggable="true" — app can be debugged/attached on a release device
[MEDIUM]   Cleartext (plain HTTP) traffic is permitted by the manifest
[HIGH] provider com.example.target.FileProvider — exported, no permission required
[+] Manifest audit complete. 6 finding(s).
```

---

## Repository Structure

```
APKX/
├── apkx.py                   # Interactive console
├── modules/
│   ├── base.py                # BaseModule class (options, validation, findings)
│   ├── apk_manifest.py
│   ├── apk_cert.py
│   └── apk_secrets.py
├── utils/
│   └── colors.py
├── samples/                   # Drop test APKs here (gitignored)
└── reports/                   # Exported JSON findings
```

---

## Known Limitations

- `apk/secrets` uses heuristic regex matching over raw file bytes (including raw `classes.dex` bytes) — it is **not** bytecode-aware. Expect occasional false positives and verify every hit manually before reporting it.
- Exported-component logic implements Android's actual default behavior (implicitly exported if an intent-filter is present and `exported` isn't set explicitly), but always double-check edge cases against the live manifest for apps targeting API 31+, where Google tightened these defaults.
- This is a **static** analysis tool only. It does not cover dynamic checks (runtime permission abuse, WebView JS bridge exploitation, traffic interception) — pair it with Frida/drozer/mitmproxy or a tool like MobSF for the dynamic half of a mobile pentest.

---

## Legal

For use only on applications you own, built yourself, or have explicit written authorization to test (client engagement, bug bounty program scope, CTF/lab). Do not redistribute secrets or proprietary code discovered during analysis. Built for educational purposes and certification preparation.
